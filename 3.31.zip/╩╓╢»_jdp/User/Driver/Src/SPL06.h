#ifndef __SPL06_H
#define __SPL06_H


void spl0601_start_continuous(uint8_t mode);
void spl0601_rateset(uint8_t iSensor, uint8_t u8SmplRate, uint8_t u8OverSmpl);

void SPL06_Init(void);
void SPL06_Read_Data(float *baro_t,float *baro_p);
void spl0601_init(void);
	
	
extern float  spl_cal_data[9];
extern struct spl0601_t *p_spl0601;
extern uint8_t baro_flag;
#endif

