#ifndef _MY_TASK_H_
#define _MY_TASK_H_

#include "WP_DataType.h"


extern uint8_t black_find(void);

#endif

