#ifndef _DEVELOPER_MODE_
#define _DEVELOPER_MODE_

extern int8_t SDK1_Mode_Setup,SDK2_Mode_Setup;

void Auto_Flight_Ctrl(uint8_t mode);


#endif



