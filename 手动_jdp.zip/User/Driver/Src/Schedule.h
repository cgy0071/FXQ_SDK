#ifndef __SCHEDULE_H__
#define __SCHEDULE_H__

#include "WP_DataType.h"
extern u32 TIME_ISR_CNT;
extern void TIMER1A_Handler(void);
void Schedule_init(void);


#endif

